const app = require ('./app')

app.listen(5000);